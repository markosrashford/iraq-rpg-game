IraqPersuasionRPG - Godot 4 project (prepared)
---------------------------------------------
Instructions:
1. Open Godot 4 and open this folder as a project.
2. In Project -> Project Settings -> AutoLoad add:
   Path: res://scripts/save_manager.gd
   Node Name: SaveManager
3. Open MainMenu.tscn and assign script (res://scripts/MainMenu.gd) if not autoassigned.
4. Run project. Scenes:
   - res://scenes/MainMenu.tscn
   - res://scenes/MapScene.tscn
   - res://scenes/ProvinceScene.tscn
   - res://scenes/DialogueScene.tscn
Notes:
- Assets (images) are in res://assets (from the archive you uploaded).
- AI offline file: res://data/ai_responses.json
- Save file: user://save_game.json
- To build APK: copy project to PC, install Android SDK/NDK/JDK and Godot export templates, then export Android.
